class RoutesNames {
  static const String home = 'home_screen';
  static const String dummy = 'dummy_screen';
  static const String onBoarding = 'onboarding_screen';
  static const String changePassowrd = 'change_password';
  static const String profile = 'profile';                   
  static const String editProfile = 'edit_Profile';
  static const String postCreateDialog = 'post_creation_dialog_Box';  
  static const String ngoDescrip='NGO_DESCRIPTION';
  static const String login='login';
  static const String signup='signup';
  static const String resetpswd='reset_password';
  static const String otp='otp';
  static const String forgetPswdEmail='forget_password_main_screen';
  static const String oldPassword='old_password';
}
