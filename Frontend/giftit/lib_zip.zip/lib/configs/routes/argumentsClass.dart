class OtpScreenArgs {
  final String email;
  final String type;

  OtpScreenArgs({required this.email, required this.type});
}
