// part of 'signup_main_bloc.dart';
// enum SignupStatus {initial,loading,fail,success}