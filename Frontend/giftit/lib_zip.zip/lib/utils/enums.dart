enum SearchStatus {
  initial,
  searching,
  success,
  failure,
}

