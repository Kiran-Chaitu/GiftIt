package com.example.giftit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
